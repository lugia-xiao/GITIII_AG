# gitiii_ag/data/__init__.py

"""
This package contains data files used by the gitiii_ag package.
"""

__version__ = "0.1.0"
